 class Car {
    constructor(plateNumber, timeIn) {
      this.plateNumber = plateNumber;
      this.timeIn = timeIn;
    }
  }

  const MAX_SPACES = 50;
  const parkingLot = new Array(MAX_SPACES).fill(null);

  // Check if parking lot is full
  function isFull() {
    return parkingLot.every(slot => slot !== null);
  }

  // Find first available slot
  function findAvailableSlot() {
    return parkingLot.findIndex(slot => slot === null);
  }

  // Park car
  function parkCar() {
    const plate = document.getElementById('plateInput').value.trim();
    const statusDiv = document.getElementById('status');

    if (plate === '') {
      statusDiv.innerHTML = 'Please enter a plate number.';
      alert('try again')
      return;
    }
    if (isFull()) {
      statusDiv.innerHTML = 'Parking lot is full.';
      return;
    }
    if (parkingLot.some(c => c && c.plateNumber === plate)) {
      statusDiv.innerHTML = 'Car with this plate is already parked.';
      return;
    }

    const index = findAvailableSlot();
    if (index !== -1) {
      parkingLot[index] = new Car(plate, new Date());
      statusDiv.innerHTML = `Car ${plate} parked at slot ${index + 1}.`;
      document.getElementById('plateInput').value = '';
      listCars();
    }
  }

  // Remove car
  function removeCar() {
    const plate = document.getElementById('removePlateInput').value.trim();
    const statusDiv = document.getElementById('status');

    const index = parkingLot.findIndex(c => c && c.plateNumber === plate);
    if (index === -1) {
      statusDiv.innerHTML = 'Car not found.';
      return;
    }
    // if(!plate){
    //     alert('please enter the plate number');
    // }

    const car = parkingLot[index];
    const timeOut = new Date();
    const durationMs = timeOut - car.timeIn;
    const hours = Math.ceil(durationMs / (1000 * 60 * 60));
    const fee = calculateFee(hours);

    parkingLot[index] = null;
    statusDiv.innerHTML = `
      Removed car ${plate} from slot ${index + 1}.<br>
      Duration: ${hours} hours.<br>
      Fee: Rwf ${fee}
    `;
    document.getElementById('removePlateInput').value = '';
    listCars();
  }

  // Calculate parking fee
  function calculateFee(hours) {
    const baseRate = 500;
    const extraRate = 300;
    return hours <= 1 ? baseRate : baseRate + (hours - 1) * extraRate;
  }

  // List all cars
  function listCars() {
    const gridDiv = document.getElementById('parkingGrid');
    gridDiv.innerHTML = '';

    for (let i = 0; i < parkingLot.length; i++) {
      const slotDiv = document.createElement('div');
      slotDiv.className = 'slot';

      const car = parkingLot[i];
      if (car) {
        slotDiv.classList.add('occupied');
        slotDiv.innerHTML = `
          <div>Slot ${i + 1}</div>
          <div class="car-info"><img src="Kia Soul Gt Line 4k Wallpaper HD Car.jpg" alt="" srcset="" width="50" height="50">   ${car.plateNumber}</div>
          <div>In: ${car.timeIn.toLocaleString()}</div>
        `;
      } else {
        slotDiv.innerHTML = `Slot ${i + 1}<br>Empty`;
      }
      gridDiv.appendChild(slotDiv);
    }
  }

  // Initialize display
  window.onload = listCars;